<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pleasewait}prestashop>pleasewait_0b171b59d90e2a5595bae5ae075d8bd1'] = 'Por favor espera...!';
$_MODULE['<{pleasewait}prestashop>pleasewait_6e5a2ae4d41d81d1439888aafed7faf5'] = 'Mostrar un icono de carga mientras carga su sitio web';
$_MODULE['<{pleasewait}prestashop>pleasewait_92328ef0a137839f00cf029c11501175'] = 'Habilitar icono de carga';
$_MODULE['<{pleasewait}prestashop>pleasewait_6d6c669b98589d5cd2abea03d3cea936'] = 'Tipo de icono de carga';
$_MODULE['<{pleasewait}prestashop>pleasewait_fc23ffe3bc715a46cc8b63071ded5fda'] = 'Tamaño de ícono';
$_MODULE['<{pleasewait}prestashop>pleasewait_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'Mensaje';
$_MODULE['<{pleasewait}prestashop>pleasewait_fa69ac6795d55bd7a44fe47ae4a7a854'] = 'Mostrar sólo en la página principal';
$_MODULE['<{pleasewait}prestashop>pleasewait_534b7c706186028f1b4f51344bbca176'] = 'Color del icono';
$_MODULE['<{pleasewait}prestashop>pleasewait_5f111ae4c490902059da2004cbc8b424'] = 'Color de texto';
$_MODULE['<{pleasewait}prestashop>pleasewait_368d9ac76af05f714092bc808a426bfc'] = 'Color de fondo';
$_MODULE['<{pleasewait}prestashop>pleasewait_96fd2b796454b8598b7029086421930c'] = 'Opacidad de fondo';
$_MODULE['<{pleasewait}prestashop>pleasewait_25e56d2ad1d3e904ef3e481e6fca76e1'] = 'La opacidad de fondo es un número de flotador de 0 a 1';
$_MODULE['<{pleasewait}prestashop>pleasewait_254f642527b45bc260048e30704edb39'] = 'Configuración';
$_MODULE['<{pleasewait}prestashop>pleasewait_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{pleasewait}prestashop>pleasewait_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{pleasewait}prestashop>pleasewait_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{pleasewait}prestashop>pleasewait_7cc92687130ea12abb80556681538001'] = 'Se ha producido un error durante el proceso de carga de la imagen';
$_MODULE['<{pleasewait}prestashop>form_9f5eba7179014f3c071cba0c406523fc'] = 'Ver todos los tipos de iconos de carga';
